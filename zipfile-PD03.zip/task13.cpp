#include<iostream>
using namespace std;
main()
{
 int x,y;
 cout<<"Enter a number = ";
 cin>>x;
 cout<<"Enter a number = "<< x+y <<endl;
 cin>>y;
 cout<<"Enter a number = "<< x+y <<endl;
 cin>>y;
 cout<<"Enter a number = "<< x+y <<endl;
 cin>>y;
 cout<<"Enter a number = "<< x+y <<endl;
 cin>>y;
 cout<<"The sum of 5 integers is = "<< x <<endl;
 return 0;
}


