#include<iostream>
using namespace std;
main()
{
  int n;
  cout<<"Enter the number of sides of a polygon= ";
  cin>>n;
  cout<<"sum of internal angles= " << (n-2) * 180 <<endl;
}