#include<iostream>
using namespace std;
main(){
int a,b=0;
cout<<"Enter a number"<<endl;
cin>>a;
b=b+a;
cout<<"Enter a number"<<endl;
cin>>a;
b=b+a;
cout<<"Enter a number"<<endl;
cin>>a;
b=b+a;
cout<<"Enter a number"<<endl;
cin>>a;
b=b+a;
cout<<"Enter a number"<<endl;
cin>>a;
b=b+a;
cout<<"The sum of 5 integers is:"<<b<<endl;

}


